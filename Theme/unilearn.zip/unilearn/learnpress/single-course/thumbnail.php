<?php
/**
 * Template for displaying thumbnail of single course.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/single-course/thumbnail.php.
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();

global $post;
$course      = learn_press_get_course();
$video_embed = $course->get_video_embed();

if ( $video_embed ) {
	?>
    <div class="course-video"><?php echo sprintf("%s", $video_embed); ?></div>
	<?php
}

if ( ! has_post_thumbnail() || $video_embed ) {
	return;
}

$thumb_dim_args = get_option( "learn_press_single_course_image_size" );
$thumb_id 		= get_post_thumbnail_id ();
$thumb_obj 		= wp_get_attachment_image_src ( $thumb_id, 'full' );
$thumb_src 		= $thumb_obj[0];
$bfi_obj 		= bfi_thumb( $thumb_src, $thumb_dim_args, false );
$thumb_url 		= $bfi_obj[0];
$retina_thumb_exists 	= false;
$retina_thumb_url 		= "";
if ( isset( $bfi_obj[3] ) && !empty( $bfi_obj[3] ) ){
	extract( $bfi_obj[3] );
}
?>

<div class='post_media lp_course_post_media post_single_post_media'>
	<div class='pic'>
		<?php
			if ( $retina_thumb_exists ) {
				echo "<img src='$thumb_url' data-at2x='$retina_thumb_url' alt />";
			}	else {
				echo "<img src='$thumb_url' data-no-retina alt />";
			}
		?>
		<div class='hover-effect'></div>
		<div class='links'>
			<a href="<?php echo sprintf("%s", $thumb_src); ?>" class='fancy fa fa-plus'></a>
		</div>
	</div>
</div>
