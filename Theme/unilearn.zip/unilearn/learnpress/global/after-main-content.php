<?php
/**
 * Template for displaying after main content.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/global/after-main-content.php.
 *
 * @author  ThimPress
 * @package  Learnpress/Templates
 * @version  3.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>
		</main>
	</div>
</div>
