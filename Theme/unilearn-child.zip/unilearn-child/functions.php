<?php

add_action( 'after_setup_theme', 'unilearn_child_theme_setup' );
function unilearn_child_theme_setup() {
    load_child_theme_textdomain( 'unilearn', get_stylesheet_directory() . '/languages' );
}

?>
